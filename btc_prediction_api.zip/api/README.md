# BTC 15m Prediction API

FastAPI server that fetches live Binance 15m candles, trains a LightGBM
classifier, and exposes a `/predict` endpoint compatible with the dashboard.

## Response format

```json
{
  "direction": "UP",
  "confidence": 57,
  "prob_up": 0.574,
  "prob_down": 0.426,
  "reasoning": "UP signal: RSI oversold (38.2), strong buy pressure (68%).",
  "indicators": {
    "rsi": 38.2,
    "macd_diff": -0.0012,
    "bb_pct": 22.4,
    "buy_pressure": 68.1,
    "vol_ratio": 1.31,
    "ret_1": -0.082,
    "ret_5": -0.31,
    "price": 67420.0
  },
  "model_accuracy": 54.3
}
```

---

## Deploy to Railway (free, ~5 min)

1. Push this folder to a GitHub repo
2. Go to https://railway.app → New Project → Deploy from GitHub
3. Select your repo → Railway auto-detects Python + Procfile
4. Wait ~2 min for build
5. Copy the generated URL (e.g. `https://btc-predictor.up.railway.app`)
6. Paste it into the dashboard as your API endpoint

### Test locally

```bash
pip install -r requirements.txt
uvicorn main:app --reload
# GET http://localhost:8000/predict
```

---

## Notes

- Model retrains every 15 minutes automatically (cached between calls)
- Fetches 2000 candles (~20 days) from Binance public API — no key needed
- Walk-forward 5-fold cross-validation, no data leakage
- Typical directional accuracy: 52–57% on BTC 15m
- Not financial advice
